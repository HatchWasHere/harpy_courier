extends Node

signal feathers_changed
signal called_got_offline_feathers_screen(feathers_got:int)
signal inventory_changed
signal current_route_changed

@onready var idle_manager: Node = %IdleManager
@onready var idle_timer: Timer = %IdleTimer
@onready var save_timer: Timer = %SaveTimer

var inventory:Array[Item] = []
var harpy_states:Dictionary = {
	"regular_harpy" : {
		"nickname" : "None",
		"equipment" : {
			"accessory" : null,
		}
	}
}

var upgrades_data:UpgradesData = UpgradesData.new()
var shop_manager:ShopManager = ShopManager.new()

var save_dirty:bool = false
var initialized:bool = false
var last_active_time:int = 0
var feathers:int = 10
var ran_offline_feathers_check:bool = false
var MAX_OFFLINE_FEATHERS:int = 1
var unlocks:Dictionary = {
	"routes" : {
		"route_1" : true,
		"route_2" : false,
		"route_3" : false,
	}
}
var harpies:Dictionary = {
	"bern" : {
		"happiness" : 0,
		"equipment" : [],
	}
}

var current_selected_route:Dictionary = {}

var all_routes:Dictionary = {
	"route_1" : {
		
	},
}
var current_harpy:Dictionary = {}

## Storage for offline feathers, used briefly to avoid weirdness. ##
var queued_offline_feathers:int = 0

var save_dir:String = "user://save_data/"
var save_path:String = save_dir + "save_data.tres"

const BASE_FEATHERS_GAINED_PER_TIMEOUT:int = 1
const BASE_TIMER_RATE:float = 5.0
const BASE_FEATHERS_GAINED_PER_MANUAL_COLLECTION:int = 5
const SAVE_TIMER_WAIT_TIME:float = 30.0
const MAX_OFFLINE_SECONDS:int = 7200

const FEATHER_BASKET_BONUS_BASE:int = 1 ## Extra feathers gained per level of 'Feather Basket.'

func _ready() -> void:
	assert(idle_manager != null)
	assert(idle_timer != null)
	
	idle_timer.one_shot = false
	idle_timer.wait_time = BASE_TIMER_RATE
	
	idle_timer.timeout.connect(on_idle_timer_timeout)
	idle_timer.start()
	
	save_timer.wait_time = SAVE_TIMER_WAIT_TIME
	save_timer.timeout.connect(on_save_timer_timeout)
	save_timer.one_shot = false
	save_timer.start()
	
	upgrades_data.upgrades_changed.connect(on_upgrades_changed)
	
	initialize_save_data()
	
	if !initialized:
		return
	
	shop_manager.load_inventory()
	
	load_game()

func change_upgrades():
	mark_as_dirty()
	save_game()

func mark_as_dirty():
	save_dirty = true

func initialize_save_data():

	var dir:DirAccess = DirAccess.open("user://")
	if dir == null:
		push_error("ERROR. Couldn't open 'user://'.")
		return

	if not dir.dir_exists("save_data"):
		var mk_err = dir.make_dir("save_data")
		if mk_err != OK:
			push_error("ERROR. Failed to create save directory.")
			return
		
	if not ResourceLoader.exists(save_path):
		var new_save_data = SaveData.new()
		new_save_data.upgrades = upgrades_data.upgrades
		ResourceSaver.save(new_save_data,save_path)
	
	initialized = true

func auto_load():
	load_game()

func collect_feathers():
	get_feathers(BASE_FEATHERS_GAINED_PER_MANUAL_COLLECTION)

func on_idle_timer_timeout():

	var u = GameManager.upgrades_data.upgrades.get("feather_basket",null)

	if u == null or u.is_empty():
		push_error("ERROR. Returned a null/empty dictionary value.")
		return

	var f = get_feather_basket_bonus_feathers()
	if f == null:
		push_error("ERROR. Feather basket bonus returned a null value.")
		return
	
	if f > 0:
		print("Gaining boosted feathers of " + str(BASE_FEATHERS_GAINED_PER_TIMEOUT + f))
	
	get_feathers(BASE_FEATHERS_GAINED_PER_TIMEOUT + f)

func get_feather_basket_bonus_feathers() -> int:
	
	## == Safety Checks == ##
	if GameManager.upgrades_data == null:
		push_error("ERROR. 'Upgrades Data' resource is missing.")
	
	if GameManager.upgrades_data.upgrades == null:
		push_error("ERROR. 'Upgrades' var is missing.")
	
	## == Get 'feather basket' upgrade. == ##
	var u = GameManager.upgrades_data.upgrades.get("feather_basket",null)
	
	if u == null: ## == Safety check == ##
		push_error("ERROR. Returned a null dictionary value.")
		return 0
	
	## == Get upgrade's level == ##
	var basket_lv = u.get("current_level",null)
	if u == null:
		push_error("ERROR. 'current_level' returned a null dictionary value.")
		return 0
	
	
	## Return bonus amount, e.g. --> gain ((2 * 1) + usual_feathers_gained) ##
	return (basket_lv * FEATHER_BASKET_BONUS_BASE)

func get_feathers(feather_amt:int):
	feathers += feather_amt
	feathers_changed.emit()
	mark_as_dirty()
	
func save_game():
	
	if not save_dirty:
		return
	
	var save_data:SaveData = SaveData.new()
	
	save_data.feathers = feathers
	save_data.upgrades = upgrades_data.upgrades
	save_data.last_active_time = last_active_time
	
	var err = ResourceSaver.save(save_data,save_path)
	if err != OK:
		push_error("ERROR. Failed saving data.")
		return
	
	save_dirty = false

func get_idle_collected_feathers(save_data:SaveData):
	
	if save_data == null:
		return 0
	
	var seconds = get_delta_time_since_last_played(save_data)
	if seconds <= 0: return 0
	seconds = min(seconds,MAX_OFFLINE_SECONDS)
	
	var feathers_per_second = float(BASE_FEATHERS_GAINED_PER_TIMEOUT) / float(BASE_TIMER_RATE)
	var reward = seconds * feathers_per_second * 0.2
	
	return reward

func get_delta_time_since_last_played(save_data:SaveData):
	var now:int = Time.get_unix_time_from_system()
	var then:int = save_data.last_active_time
	
	if then <= 0:
		return 0
	
	var delta_seconds:float = max(0, now - then)
	return delta_seconds

func _exit_tree() -> void:
	if save_dirty:
		save_game()

func _notification(what):
	if what == NOTIFICATION_APPLICATION_PAUSED:
		last_active_time = Time.get_unix_time_from_system()
		mark_as_dirty()
		save_if_dirty()

func load_game():
	var now:int = Time.get_unix_time_from_system()
	var load_data:SaveData = ResourceLoader.load(save_path)
	
	if load_data == null: return
	
	feathers = load_data.feathers
	upgrades_data.upgrades = load_data.upgrades
	
	var offline_feathers:int = get_idle_collected_feathers(load_data)
	if offline_feathers > 0:
		offline_feathers = min(MAX_OFFLINE_FEATHERS,offline_feathers)
		store_offline_feathers(offline_feathers)
		feathers += offline_feathers
		feathers_changed.emit()
	last_active_time = now
	mark_as_dirty()
	save_if_dirty()

func save_if_dirty():
	if save_dirty:
		save_game()

func on_save_timer_timeout():
	save_if_dirty()


## Store feathers gained while offline--cleared quickly. ##

func store_offline_feathers(feather_count:int):
	queued_offline_feathers = feather_count

func clear_offline_feathers():
	queued_offline_feathers = 0

func on_upgrades_changed():
	mark_as_dirty()
	save_game()

func spend_feathers(amt:int):
	feathers -= amt
	feathers_changed.emit()

func add_item_to_inventory(item:Item):
	inventory.append(item.duplicate())
	GameManager.mark_as_dirty()
	GameManager.save_game()
	inventory_changed.emit()

func remove_item_from_inventory(item:Item):
	var idx:int = 0
	var id = item.item_id
	
	for i in inventory:
		
		if i == null: continue
		
		if id == i.item_id:
			inventory.remove_at(idx)
			GameManager.mark_as_dirty()
			GameManager.save_game()
			inventory_changed.emit()
			break
		else:
			idx += 1
	
	push_error("ERROR. Did not remove item.")

func can_afford_item(item:Item) -> bool:
	
	if item.item_value == null or item.item_value <= 0:
		return false
	
	if feathers < item.item_value:
		return false
	
	return true

func set_current_route(new_route_id:String):
	
	if not all_routes.has(new_route_id):
		push_error("ERROR. Can't find route with a key of %s. Setting to empty...")
		current_selected_route = {}
	
	else:
		var picked_route = all_routes.get(new_route_id)
		current_selected_route = picked_route

	current_route_changed.emit()
