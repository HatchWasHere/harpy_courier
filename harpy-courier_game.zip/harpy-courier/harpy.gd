extends Resource
class_name HarpyResource

@export var harpy_name:String
@export var harpy_id:String
@export var favorite_items:Array = []
@export var feathers_earned_multiplier:float = 1.0
