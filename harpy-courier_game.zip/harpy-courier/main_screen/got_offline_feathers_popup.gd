extends Control
class_name GotOfflineFeathersPopup

signal finished_fade_tween

var offline_feathers_got:int = 0

@onready var confirm_button: Button = %ConfirmButton
@onready var offline_feathers_text_label: Label = %OfflineFeathersTextLabel

func _ready() -> void:
	
	modulate = Color.TRANSPARENT
	
	confirm_button.pressed.connect(on_pressed_confirm_button)
	set_popup_text()
	
	await fade_window(1.0)

func on_pressed_confirm_button():
	await fade_window(0.0)
	queue_free()

func fade_window(alpha:float):
	var fade_time:float = 0.15
	var tween:Tween = create_tween()
	tween.tween_property(self,"modulate:a",alpha,fade_time)
	await tween.finished
	finished_fade_tween.emit()

func set_popup_text():
	offline_feathers_text_label.text = "Your harpies continued working while you were away! They gathered %d feathers!" % [offline_feathers_got]
	
