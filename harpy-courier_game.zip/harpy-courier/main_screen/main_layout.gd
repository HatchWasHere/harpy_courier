extends Control

@onready var quit_button: Button = %QuitButton

func _ready() -> void:
	
	assert(quit_button != null)
	if quit_button == null: return
	
	quit_button.pressed.connect(on_pressed_quit_button)
	got_offline_feathers_popup()

func on_pressed_quit_button():
	var quit_confirm_screen = load("res://main_screen/quit_confirm_window.tscn").instantiate()
	add_child(quit_confirm_screen)

func got_offline_feathers_popup():
	
	if GameManager.ran_offline_feathers_check:
		return
	
	if GameManager.queued_offline_feathers > 0:
		var scene = load("res://main_screen/got_offline_feathers_popup.tscn").instantiate()
		scene.offline_feathers_got = GameManager.queued_offline_feathers
		add_child(scene)
		GameManager.clear_offline_feathers()
	
	GameManager.ran_offline_feathers_check = true
