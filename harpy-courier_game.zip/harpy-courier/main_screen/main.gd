extends Control
class_name MainScreen

@onready var feathers_display: Label = %FeathersDisplay
@onready var manual_collect_button: Button = %ManualCollectButton
@onready var stats_button: Button = %StatsButton
@onready var work_button: Button = %WorkButton
@onready var upgrade_button: Button = %UpgradeButton
@onready var shop_button: Button = %ShopButton
@onready var main_layout: Control = %MainLayout
@onready var next_scene: Control = %NextScene

func _ready() -> void:
	GameManager.feathers_changed.connect(on_feathers_count_changed)
	GameManager.called_got_offline_feathers_screen.connect(on_called_offline_feathers_popup)
	shop_button.pressed.connect(on_pressed_shop_button)
	manual_collect_button.pressed.connect(on_pressed_collect_feathers_button)
	upgrade_button.pressed.connect(on_pressed_upgrade_button)

	set_feathers_display()

func on_called_offline_feathers_popup(feathers:int):
	var popup_scene = load("res://main_screen/got_offline_feathers_popup.tscn")
	var scene = popup_scene.instantiate()
	scene.offline_feathers_got = feathers
	main_layout.add_child(scene)

func on_feathers_count_changed():
	set_feathers_display()

func set_feathers_display():
	feathers_display.text = "FEATHERS: %d" % [GameManager.feathers]

func on_pressed_collect_feathers_button():
	manually_collect_feathers()

func manually_collect_feathers():
	GameManager.collect_feathers()

func call_upgrade_screen():
	var u_screen:PackedScene = load("res://main_screen/upgrades_screen.tscn")
	var s = u_screen.instantiate()
	main_layout.add_child(s)

func on_pressed_upgrade_button():
	call_upgrade_screen()

func on_pressed_shop_button():
	var shop_scene = load("res://shop_screen.tscn").instantiate()
	main_layout.hide()
	next_scene.add_child(shop_scene)
	next_scene.show()
	shop_scene.closed_secondary_scene.connect(on_returned_to_main_screen)

func on_returned_to_main_screen():
	next_scene.hide()
	main_layout.show()
