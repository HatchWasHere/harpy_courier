extends Resource
class_name SaveData

@export var feathers:int = 0
@export var upgrades:Dictionary = {}
@export var last_active_time:int = 0
@export var harpy_states:Dictionary = {}
