extends Resource
class_name DefaultShopInventory

@export var inventory:Array[Item] = [
	load("res://equipment/test_equipment_item.tres")
]
