extends RefCounted
class_name HarpyTraitEnums

enum harpy_trait {
	NIGHT_OWL,
	PEOPLE_PLEASER,
}
