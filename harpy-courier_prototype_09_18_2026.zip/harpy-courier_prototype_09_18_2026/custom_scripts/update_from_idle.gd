extends RefCounted
class_name UpdateFromIdle



static func get_idle_collected_feathers(save_data:SaveData) -> int:
	
	var reward:int = 0
	
	if save_data == null:
		return 0
	
	var seconds = get_delta_time_since_last_played(save_data)
	if seconds <= 0: return 0
	seconds = min(seconds,GameManager.MAX_OFFLINE_SECONDS)
	
	var feathers_per_second = float(GameManager.BASE_FEATHERS_GAINED_PER_TIMEOUT) / float(GameManager.BASE_TIMER_RATE)
	
	for h in GameManager.harpies:
		
		var entry = GameManager.harpies.get(h,{})
		if entry.is_empty():
			continue

		var harpy:HarpyResource = entry.get("data",null)
		if harpy == null:
			continue
		
		var h_mult = harpy.feathers_earned_multiplier
		
		reward += (seconds * feathers_per_second * 0.2) * h_mult
	
	print("Got %d feathers while offline." % [reward])
	
	return reward

static func get_delta_time_since_last_played(save_data:SaveData):
	var now:int = Time.get_unix_time_from_system()
	var then:int = save_data.last_active_time
	
	if then <= 0:
		return 0
	
	var delta_seconds:float = max(0, now - then)
	return delta_seconds


static func get_rewards_from_offline(save_data:SaveData) -> Dictionary:
	
	var materials_per_second:int = 0
	var feathers_per_second:int = 0
	
	var rewards:Dictionary = {"feathers" : 0, "materials": 0, "gifts" : []}
	
	if GameManager.current_route.is_empty():
		return rewards
	
	var seconds = get_delta_time_since_last_played(save_data)
	if seconds <= 0: return rewards
	seconds = min(seconds,GameManager.MAX_OFFLINE_SECONDS)
	
	feathers_per_second = int(GameManager.BASE_FEATHERS_GAINED_PER_TIMEOUT) / float(GameManager.BASE_TIMER_RATE)
	materials_per_second = int(GameManager.BASE_MATERIALS_GAINED_PER_TIMEOUT) / float(GameManager.BASE_TIMER_RATE)
	
	for i in GameManager.harpies:
		
		var entry:Dictionary = GameManager.harpies.get(i,{})
		var harpy:HarpyResource = GameManager.harpies[entry].get("data")
		
		var h_feather_mult = harpy.feathers_earned_multiplier
		var h_materials_mult = harpy.materials_earned_multiplier
		
		rewards["feathers"] += (seconds * feathers_per_second * 0.2) * h_feather_mult
		rewards["materials"] += (seconds * materials_per_second * 0.2) * h_materials_mult
	
	return rewards
