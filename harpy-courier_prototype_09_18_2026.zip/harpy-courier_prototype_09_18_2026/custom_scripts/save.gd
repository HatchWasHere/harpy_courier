extends RefCounted
class_name _Save
