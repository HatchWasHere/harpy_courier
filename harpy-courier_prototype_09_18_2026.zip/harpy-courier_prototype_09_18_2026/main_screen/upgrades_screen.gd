extends Control
class_name UpgradesScreen

@onready var upgrade_buttons_container: VBoxContainer = %UpgradeButtonsContainer
@onready var description_label: Label = %DescriptionLabel
@onready var back_button: Button = %BackButton
@onready var confirm_buy_button: Button = %ConfirmBuyButton
@onready var cancel_buy_button: Button = %CancelBuyButton
@onready var confirm_upgrade_buy_screen: CanvasLayer = %ConfirmUpgradeBuyScreen
@onready var buy_upgrade_button: Button = %BuyUpgradeButton


var picked_upgrade_id:String

func _ready() -> void:
	cancel_buy_button.pressed.connect(on_pressed_cancel_confirm_buy)
	confirm_buy_button.pressed.connect(on_pressed_confirm_buy)
	buy_upgrade_button.pressed.connect(on_pressed_buy_button)
	back_button.pressed.connect(on_pressed_back_button)
	var buttons = get_upgrade_buttons()
	assert(buttons != null and not buttons.is_empty())
	
	for b in buttons:
		upgrade_buttons_container.add_child(b)

func on_pressed_cancel_confirm_buy():
	picked_upgrade_id = ""
	confirm_upgrade_buy_screen.hide()

func on_pressed_confirm_buy():
	
	if GameManager.upgrades_data.can_upgrade(picked_upgrade_id) == false:
		confirm_upgrade_buy_screen.hide()
		return
	GameManager.upgrades_data.buy_upgrade(picked_upgrade_id)
	confirm_upgrade_buy_screen.hide()
	picked_upgrade_id = ""

func on_pressed_back_button():
	queue_free()

func get_upgrade_buttons() -> Array[Button]:
	var buttons:Array[Button] = []
	
	assert(GameManager.upgrades_data != null)
	assert(GameManager.upgrades_data.upgrades != null)
	assert(GameManager.upgrades_data.upgrades.is_empty() == false)
	
	for u in GameManager.upgrades_data.upgrades:
		var rec = GameManager.upgrades_data.upgrades.get(u,null)
		if rec == null: continue
		
		var new_button:Button = Button.new()
		new_button.custom_minimum_size = Vector2(0,150)
		new_button.add_theme_font_size_override("font_size",48)
		new_button.text = rec.get("name",null)
		new_button.pressed.connect(on_pressed_upgrade_button.bind(rec))
		buttons.append(new_button)
	
	return buttons

func on_pressed_buy_button():
	if picked_upgrade_id == null or picked_upgrade_id.is_empty():
		push_error("ERROR. No upgrade ID to pass as an argument.")
		return
	
	if GameManager.upgrades_data.can_upgrade(picked_upgrade_id) == false:
		return
	
	confirm_upgrade_buy_screen.show()

func on_pressed_upgrade_button(u_dict:Dictionary):
	picked_upgrade_id = u_dict.get("id","ERROR")
	var desc = u_dict.get("description","ERROR")
	description_label.text = desc
	

func get_upgrade_dict(id:String) -> Dictionary:
	var dict:Dictionary
	dict = GameManager.upgrades_data.upgrades.get(id,null)
	if dict == null:
		push_error("ERROR. Could not find key '" + id + "'!")
	
	return dict
