extends Control

var quit_confirm_screen:PackedScene = load("res://main_screen/quit_confirm_window.tscn")
var offline_rewards_screen:PackedScene = load("res://main_screen/got_offline_feathers_popup.tscn")

@onready var quit_button: Button = %QuitButton

func _ready() -> void:

	quit_button.pressed.connect(on_pressed_quit_button)
	show_feathers_gained_while_offline()

func on_pressed_quit_button():
	add_child(quit_confirm_screen.instantiate())

func show_feathers_gained_while_offline():
	
	if GameManager.ran_offline_feathers_check:
		return
	
	if GameManager.queued_offline_feathers > 0:
		var popup = offline_rewards_screen.instantiate()
		popup.offline_feathers_got = GameManager.queued_offline_feathers
		add_child(popup)
