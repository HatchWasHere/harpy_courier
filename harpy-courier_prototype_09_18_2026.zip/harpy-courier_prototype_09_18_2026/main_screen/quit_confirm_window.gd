extends CanvasLayer

@onready var confirm_quit_button: Button = %ConfirmQuitButton
@onready var cancel_quit_button: Button = %CancelQuitButton

func _ready() -> void:
	confirm_quit_button.pressed.connect(on_pressed_confirm_quit_button)
	cancel_quit_button.pressed.connect(on_pressed_cancel_quit_button)

func on_pressed_confirm_quit_button():
	GameManager.mark_as_dirty()
	GameManager.save_game()
	await get_tree().process_frame
	get_tree().quit()

func on_pressed_cancel_quit_button():
	queue_free()
