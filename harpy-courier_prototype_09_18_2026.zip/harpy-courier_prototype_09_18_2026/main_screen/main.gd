extends Control
class_name MainScreen

@onready var feathers_display: Label = %FeathersDisplay
@onready var stats_button: Button = %StatsButton
@onready var work_button: Button = %WorkButton
@onready var upgrade_button: Button = %UpgradeButton
@onready var shop_button: Button = %ShopButton
@onready var main_layout: Control = %MainLayout
@onready var next_scene: Control = %NextScene

func _ready() -> void:
	GameManager.feathers_changed.connect(on_feathers_count_changed)
	shop_button.pressed.connect(on_pressed_shop_button)
	upgrade_button.pressed.connect(on_pressed_upgrade_button)

	set_feathers_display()

func on_feathers_count_changed():
	set_feathers_display()

func set_feathers_display():
	feathers_display.text = "FEATHERS: %d" % [GameManager.feathers]

func call_upgrade_screen():
	var u_screen:PackedScene = load("res://main_screen/upgrades_screen.tscn")
	var s = u_screen.instantiate()
	main_layout.add_child(s)

func on_pressed_upgrade_button():
	call_upgrade_screen()

func on_pressed_shop_button():
	var shop_scene = load("res://shop_screen.tscn").instantiate()
	main_layout.hide()
	next_scene.add_child(shop_scene)
	next_scene.show()
	shop_scene.closed_secondary_scene.connect(on_returned_to_main_screen)

func on_returned_to_main_screen():
	next_scene.hide()
	main_layout.show()
