extends RefCounted
class_name _Util



### == SAVING FUNCTIONALITY == ###

const SAVE_DATA_PATH:String = ""
const save_dir:String = "user://save_data/"
const save_path:String = save_dir + "save_data.tres"

## Fetches save data--Generates an empty SaveData object if none exists. ##
static func get_save_data() -> SaveData:
	
	var data:SaveData
	
	var dir:DirAccess = DirAccess.open("user://")
	if dir == null:
		push_error("ERROR. Couldn't open 'user://'.")
		return SaveData.new()

	if not dir.dir_exists("save_data"):
		var mk_err = dir.make_dir("save_data")
		if mk_err != OK:
			push_error("ERROR. Failed to create save directory.")
			return SaveData.new()
		
	if not ResourceLoader.exists(SAVE_DATA_PATH):
		data = ResourceLoader.load(SAVE_DATA_PATH)
	
	return data

static func update_from_save_data() -> void:
	var save_data:SaveData = get_save_data()

	GameManager.feathers = save_data.feathers
	GameManager.last_active_time = save_data.last_active_time

static func update_all_harpies_from_save_data(save_data:SaveData) -> void:
	
	if save_data == null:
		return
	
	if save_data.harpies.is_empty():
		return
	
	if GameManager.harpies.is_empty():
		return
	
	for h in GameManager.harpies:
		
		var local_entry:Dictionary = GameManager.harpies.get(h,{})
		var harpy = local_entry.get("data",null)
		if harpy == null:
			push_error("ERROR when fetching HarpyResource object. Skipping...")
			continue
		
		var saved_stats_dict:Dictionary = save_data.harpies.get(h,{})
		
		var data_dict:Dictionary = GameManager.harpies.get(h,{})
		if data_dict.is_empty():
			continue


		update_harpy_from_dict(harpy,data_dict)

static func get_harpy_data_as_dict(harpy:HarpyResource) -> Dictionary:

	var dict:Dictionary = {}
	
	dict["name"] = harpy.harpy_name
	dict["id"] = harpy.harpy_id
	dict["energy"] = harpy.energy
	dict["max_feather_capacity"] = harpy.max_feather_capacity
	
	return dict

static func update_harpy_from_dict(harpy:HarpyResource, data:Dictionary) -> void:

	if data.is_empty():
		push_error("ERROR. Can't update. Empty dictionary.")
		return

	if harpy == null:
		push_error("ERROR. Null harpy resource.")
		return

	assert(data.get("name",null) != null)
	assert(data.get("id",null) != null)
	assert(data.get("energy",null) != null)
	assert(data.get("max_feather_capacity",null) != null)

	harpy.harpy_name = data.get("name",null)
	harpy.harpy_id = data.get("id",null)
	harpy.energy = data.get("energy",null)
	harpy.max_feather_capacity = data.get("max_feather_capacity",null)


static func initialize_save_data():

	

	var dir:DirAccess = DirAccess.open("user://")
	if dir == null:
		push_error("ERROR. Couldn't open 'user://'.")
		return

	if not dir.dir_exists("save_data"):
		var mk_err = dir.make_dir("save_data")
		if mk_err != OK:
			push_error("ERROR. Failed to create save directory.")
			return
		
	if not ResourceLoader.exists(save_path):
		var new_save_data = SaveData.new()
		ResourceSaver.save(new_save_data,save_path)
	
	GameManager.initialized = true


static func load_game():
	var now:int = Time.get_unix_time_from_system()
	var load_data:SaveData = ResourceLoader.load(save_path)
	
	if load_data == null:
		push_error("ERROR when fetching save data.")
		return
	
	update_local_harpy_data(load_data)
	
	## Get feathers collected offline and store them.
	
	var offline_rewards:Dictionary = UpdateFromIdle.get_rewards_from_offline(load_data)
	var offline_feathers:int = offline_rewards.get("feathers",0)
	var offline_materials:int = offline_rewards.get("materials",0)
	
	if offline_feathers > 0:
		offline_feathers = min(GameManager.MAX_OFFLINE_FEATHERS,offline_feathers)
		store_offline_feathers(offline_feathers)
		store_offline_materials(offline_materials)
		GameManager.feathers += offline_feathers
		GameManager.feathers_changed.emit()
	
	GameManager.last_active_time = now

static func update_local_harpy_data(save_data:SaveData):
	for h in GameManager.harpies:
		
		## Get the dictionary entry in GameManager with the local harpy data.
		var entry:Dictionary = GameManager.harpies.get(h,{})
		if entry.is_empty():
			continue
		
		## Get its ID
		var h_id = entry.get("id","")
		
		## Get the actual live HarpyResource data.
		var local_data = entry.get("data")
		
		## Safety check
		if not save_data.harpies.has(h_id):
			push_error("ERROR. Save data var 'harpies' is missing an entry for %s." % [h_id])
			continue
	
		var dict_data = save_data.harpies.get(h_id,{})
		
		_Util.update_harpy_from_dict(local_data,dict_data)


static func store_offline_feathers(feather_count:int):
	
	if not GameManager.resources_gathered.has("feathers"):
		push_error("ERROR. 'feathers' key not found in var 'resources_gathered.' Adding key.")
		GameManager.resources_gathered["feathers"] = 0
	
	GameManager.resources_gathered["feathers"] += feather_count
	
	GameManager.queued_offline_feathers = feather_count

static func store_offline_materials(material_count:int):
	if not GameManager.resources_gathered.has("materials"):
		push_error("ERROR. 'materials' key not found in var 'resources_gathered.' Adding key.")
		GameManager.resources_gathered["materials"] = 0
	
	GameManager.resources_gathered["materials"] += material_count
	
	GameManager.queued_offline_materials = material_count
