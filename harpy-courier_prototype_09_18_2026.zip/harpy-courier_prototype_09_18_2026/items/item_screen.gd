extends Control

func on_pressed_back_button():
	pass

func get_current_held_items():
	pass

func get_current_harpy():
	pass

func load_held_items():
	pass
