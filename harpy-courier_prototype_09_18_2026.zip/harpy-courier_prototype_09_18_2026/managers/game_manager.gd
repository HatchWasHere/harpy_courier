extends Node

signal feathers_changed
signal called_got_offline_feathers_screen(feathers_got:int)
signal inventory_changed
signal current_route_changed

@onready var idle_manager: Node = %IdleManager
@onready var idle_timer: Timer = %IdleTimer
@onready var save_timer: Timer = %SaveTimer

var inventory:Array[Item] = []
var harpy_states:Dictionary = {
	"regular_harpy" : {
		"nickname" : "None",
		"equipment" : {
			"accessory" : null,
		}
	}
}
var resources_gathered:Dictionary = {
	"feathers" : 0,
}
var upgrades_data:UpgradesData = UpgradesData.new()
var shop_manager:ShopManager = ShopManager.new()

var save_dirty:bool = false
var initialized:bool = false
var last_active_time:int = 0
var feathers:int = 10
var ran_offline_feathers_check:bool = false
var MAX_OFFLINE_FEATHERS:int = 100
var unlocks:Dictionary = {
	"routes" : {
		"route_1" : true,
		"route_2" : false,
		"route_3" : false,
	}
}
var harpies:Dictionary = {
	"bern" : {"data": load("res://harpies/bern.tres").duplicate(true),"id" : "bern"}
	}

var current_selected_route:String = "route_1"
var current_route:Dictionary = {}
var routes:Dictionary = {
	"route_1" : {
		"route_name" : "Scenic Route",
		"gift_chance" : 5,
		"materials_per_second": 2,
		"feathers_per_second" : 1,
		"percent_complete" : 0,
	},
	"route_2" : {
		"route_name" : "Whitehill Street",
		"feathers_per_second" : 1,
		"percent_complete" : 0,
	},
}
var current_harpy:Dictionary = {}

## Storage for offline feathers, used briefly to avoid weirdness. ##
var queued_offline_feathers:int = 0
var queued_offline_materials:int = 0
var save_dir:String = "user://save_data/"
var save_path:String = save_dir + "save_data.tres"

const BASE_FEATHERS_GAINED_PER_TIMEOUT:int = 1
const BASE_MATERIALS_GAINED_PER_TIMEOUT:int = 2
const BASE_TIMER_RATE:float = 5.0
const BASE_FEATHERS_GAINED_PER_MANUAL_COLLECTION:int = 5
const SAVE_TIMER_WAIT_TIME:float = 30.0
const MAX_OFFLINE_SECONDS:int = 7200

const FEATHER_BASKET_BONUS_BASE:int = 1 ## Extra feathers gained per level of 'Feather Basket.'


func set_up_timers():
	idle_timer.one_shot = false
	idle_timer.wait_time = BASE_TIMER_RATE
	idle_timer.timeout.connect(on_idle_timer_timeout)
	
	## Start running idle timer
	idle_timer.start()
	
	## Set up save timer
	
	save_timer.wait_time = SAVE_TIMER_WAIT_TIME
	save_timer.timeout.connect(on_save_timer_timeout)
	save_timer.one_shot = false
	save_timer.start()

func _ready() -> void:

	set_up_timers()
	initialize_save_data() ## Verifies save data exists--makes it new, if not
	
	if !initialized:
		push_error("ERROR during save data initializing. Check operations.")
		return
	
	load_game()

func load_game():
	_Util.load_game()

func mark_as_dirty():
	save_dirty = true

func initialize_save_data():
	_Util.initialize_save_data()

func on_idle_timer_timeout():

	var u = GameManager.upgrades_data.upgrades.get("feather_basket",null)

	if u == null or u.is_empty():
		push_error("ERROR. Returned a null/empty dictionary value.")
		return

	var f = get_feather_basket_bonus_feathers()
	if f == null:
		push_error("ERROR. Feather basket bonus returned a null value.")
		return
	
	if f > 0:
		print("Gaining boosted feathers of " + str(BASE_FEATHERS_GAINED_PER_TIMEOUT + f))
	
	get_feathers(BASE_FEATHERS_GAINED_PER_TIMEOUT + f)

func get_feather_basket_bonus_feathers() -> int:
	
	## == Safety Checks == ##
	if GameManager.upgrades_data == null:
		push_error("ERROR. 'Upgrades Data' resource is missing.")
	
	if GameManager.upgrades_data.upgrades == null:
		push_error("ERROR. 'Upgrades' var is missing.")
	
	## == Get 'feather basket' upgrade. == ##
	var u = GameManager.upgrades_data.upgrades.get("feather_basket",null)
	
	if u == null: ## == Safety check == ##
		push_error("ERROR. Returned a null dictionary value.")
		return 0
	
	## == Get upgrade's level == ##
	var basket_lv = u.get("current_level",null)
	if u == null:
		push_error("ERROR. 'current_level' returned a null dictionary value.")
		return 0
	
	
	## Return bonus amount, e.g. --> gain ((2 * 1) + usual_feathers_gained) ##
	return (basket_lv * FEATHER_BASKET_BONUS_BASE)

func get_feathers(feather_amt:int):
	feathers += feather_amt
	feathers_changed.emit()
	mark_as_dirty()
	
func save_game():
	
	if not save_dirty:
		return
	
	var save_data:SaveData = SaveData.new()
	
	var harpy_dicts:Dictionary = {}
	
	for h in GameManager.harpies:
		
		var h_dict:Dictionary = {}
		var entry = GameManager.harpies.get(h,{})
		var id = entry.get("id","")
		var data = entry.get("data")
		
		h_dict = {id : _Util.get_harpy_data_as_dict(data)}
		harpy_dicts.merge(h_dict)
	save_data.harpies = harpy_dicts
	save_data.feathers = feathers
	save_data.upgrades = upgrades_data.upgrades
	save_data.last_active_time = last_active_time
	
	var err = ResourceSaver.save(save_data,save_path)
	if err != OK:
		push_error("ERROR. Failed saving data.")
		return
	
	save_dirty = false

func get_delta_time_since_last_played(save_data:SaveData):
	var now:int = Time.get_unix_time_from_system()
	var then:int = save_data.last_active_time
	
	if then <= 0:
		return 0
	
	var delta_seconds:float = max(0, now - then)
	return delta_seconds

func _exit_tree() -> void:
	if save_dirty:
		save_game()

func _notification(what):
	if what == NOTIFICATION_APPLICATION_PAUSED:
		last_active_time = Time.get_unix_time_from_system()
		mark_as_dirty()
		save_if_dirty()

func update_local_harpy_data(save_data:SaveData):
	for h in GameManager.harpies:
		
		## Get the dictionary entry in GameManager with the local harpy data.
		var entry:Dictionary = GameManager.harpies.get(h,{})
		if entry.is_empty():
			continue
		
		## Get its ID
		var h_id = entry.get("id","")
		
		## Get the actual live HarpyResource data.
		var local_data = entry.get("data")
		
		## Safety check
		if not save_data.harpies.has(h_id):
			push_error("ERROR. Save data var 'harpies' is missing an entry for %s." % [h_id])
			continue
	
		var dict_data = save_data.harpies.get(h_id,{})
		
		_Util.update_harpy_from_dict(local_data,dict_data)

func save_if_dirty():
	if save_dirty:
		save_game()

func on_save_timer_timeout():
	save_if_dirty()


## Store feathers gained while offline--cleared quickly. ##

func clear_offline_feathers():
	queued_offline_feathers = 0

func on_upgrades_changed():
	mark_as_dirty()
	save_game()

func spend_feathers(amt:int):
	feathers -= amt
	feathers_changed.emit()

func add_item_to_inventory(item:Item):
	inventory.append(item.duplicate())
	GameManager.mark_as_dirty()
	GameManager.save_game()
	inventory_changed.emit()

func remove_item_from_inventory(item:Item):
	var idx:int = 0
	var id = item.item_id
	
	for i in inventory:
		
		if i == null: continue
		
		if id == i.item_id:
			inventory.remove_at(idx)
			GameManager.mark_as_dirty()
			GameManager.save_game()
			inventory_changed.emit()
			break
		else:
			idx += 1
	
	push_error("ERROR. Did not remove item.")

func can_afford_item(item:Item) -> bool:
	
	if item.item_value == null or item.item_value <= 0:
		return false
	
	if feathers < item.item_value:
		return false
	
	return true

func set_current_route(new_route_id:String):
	
	if not routes.has(new_route_id):
		push_error("ERROR. Can't find route with a key of %s. Setting to empty...")
		current_selected_route = ""
	
	else:
		var picked_route = routes.get(new_route_id)
		current_selected_route = picked_route

	current_route_changed.emit()

func get_feathers_gathered_when_offline() -> int:
	
	var resources:int = resources_gathered.get("feathers",null)
	if resources == null:
		push_error("ERROR. Missing 'feathers' key.")
		push_error("Resources Gathered: " + str(resources_gathered))
		return 0

	return resources


#func load_game():
	#var now:int = Time.get_unix_time_from_system()
	#var load_data:SaveData = ResourceLoader.load(save_path)
	#
	#if load_data == null:
		#return
	#
	#var offline_rewards:Dictionary = UpdateFromIdle.get_rewards_from_offline(load_data)
	#
	### Load feathers from previous sessions.
	### NOTE: The feathers gathered offline have not been added yet.
	#
	#feathers = load_data.feathers 
	#upgrades_data.upgrades = load_data.upgrades
	#update_local_harpy_data(load_data)
	#
	### Get feathers collected offline and store them.
	#
	#var offline_feathers:int = offline_rewards.get("feathers",0)
	#var offline_materials:int = offline_rewards.get("materials",0)
	#
	#if offline_feathers > 0:
		#offline_feathers = min(MAX_OFFLINE_FEATHERS,offline_feathers)
		#store_offline_feathers(offline_feathers)
		#store_offline_materials(offline_materials)
		#feathers += offline_feathers
		#feathers_changed.emit()
	#
	#last_active_time = now
	#mark_as_dirty()
	#save_if_dirty()
