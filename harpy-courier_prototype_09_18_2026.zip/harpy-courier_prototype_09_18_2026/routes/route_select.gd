extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	print(str(get_unlocked_routes()))



func get_unlocked_routes() -> Array[String]:
	
	var routes:Array[String] = []
	
	var route_unlocks = GameManager.unlocks.get("routes",{})
	if route_unlocks.is_empty():
		push_error("ERROR. Returned empty dictionary.")
	
	else:
		for r in route_unlocks:
			var unlocked = route_unlocks.get(r,false)
			if unlocked:
				routes.append(r)
	
	return routes
		
