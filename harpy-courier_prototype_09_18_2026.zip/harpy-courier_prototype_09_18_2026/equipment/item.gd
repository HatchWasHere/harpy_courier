extends Resource
class_name Item

@export var item_name:String
@export var item_id:String
@export_multiline var item_description:String
@export var item_value:int = 100
