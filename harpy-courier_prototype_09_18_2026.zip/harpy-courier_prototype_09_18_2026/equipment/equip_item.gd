extends Item
class_name Equipment

@export var effects:Array[Dictionary] = [
	{"max_feathers_up" : 10}
]
