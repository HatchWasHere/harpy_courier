extends Resource
class_name ShopManager

var inventory:Array[Item] = []

func buy_item(item:Item):
	
	if item == null: return
	if not "item_value" in item: return
	
	GameManager.spend_feathers(item.item_value)
	GameManager.add_item_to_inventory(item)

func load_inventory() -> void:
	var shop_inv:DefaultShopInventory = load("res://default_shop_inventory.tres")
	if shop_inv == null or not "inventory" in shop_inv: return
	if shop_inv.inventory == null or shop_inv.inventory.is_empty(): return
	
	for i in shop_inv.inventory:
		
		if i == null: continue
		if not i is Item: continue
		
		var loaded_item = i.duplicate(true) as Item
		inventory.append(loaded_item)
		

func can_buy_item(item) -> bool:
	
	var feathers = GameManager.feathers
	var cost = item.item_value
	
	if feathers >= cost:
		return true
	
	return false
