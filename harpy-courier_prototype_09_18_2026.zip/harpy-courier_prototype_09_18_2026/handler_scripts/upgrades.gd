extends Resource
class_name UpgradesData

signal upgrades_changed 

var upgrades:Dictionary = {
	"feather_basket" : {
		"id" : "feather_basket",
		"name" : "Feather Basket",
		"description" : "Increase the number of feathers gathered in idle mode.",
		"current_level" : 0,
		"max_level": 10,
		"base_cost": 65},
	"aerial_acrobatics" : {
		"id" : "aerial_acrobatics",
		"name" : "Aerial Acrobatics",
		"description" : "Increase feathers gained during active collection.",
		"current_level" : 0,
		"max_level": 10,
		"base_cost": 80
	},
	"bigger_satchel" : {
		"id": "bigger_satchel",
		"name" : "Bigger Satchel",
		"description" : "Increase the maximum feathers harpies can gather in Idle mode.",
		"current_level" : 0,
		"max_level": 10,
		"base_cost": 150
		
	}
}

func get_upgrade_cost(u_id:String,power:float = 1.6):
	var u = upgrades.get(u_id,null)
	assert(u != null)
	
	var cost = u.get("base_cost",null)
	assert(cost != null)
	
	var lv = u.get("current_level",null)
	assert(lv != null)

	return int(cost * pow(lv + 1, power))

func on_pressed_upgrade_button(upgrade_id:String):
	
	if not can_upgrade(upgrade_id): return
	
	buy_upgrade(upgrade_id)
	
func can_upgrade(upgrade_id:String) -> bool:
	
	## == Verify key 'upgrade_id' exists. == ##
	var u_dict = upgrades.get(upgrade_id,null)
	
	## == Safety check == ##
	if u_dict == null or u_dict.is_empty():
		push_error("ERROR. Couldn't find upgrade key '" + upgrade_id + "'.")
		return false
	
	## == Get current + max level == ##
	var lv = u_dict.get("current_level",null)
	var max_lv = u_dict.get("max_level",null)
	
	## == Safey checks == ##
	if lv == null or max_lv == null:
		push_error("ERROR. Var 'lv' or 'max_lv' returned null.")
		return false
	
	## == Can't upgrade if maxed out. == ##
	if lv < max_lv:
		return true
	
	return false

func buy_upgrade(upgrade_id:String):
	var cost:int = get_upgrade_cost(upgrade_id)
	if cost <= GameManager.feathers:
		GameManager.spend_feathers(cost)
		upgrades[upgrade_id]["current_level"] += 1
		upgrades_changed.emit()
	
	
	
	
