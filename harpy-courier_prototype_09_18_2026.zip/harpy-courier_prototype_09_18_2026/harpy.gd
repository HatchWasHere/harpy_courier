extends Resource
class_name HarpyResource

@export var harpy_name:String
@export var harpy_id:String
@export var favorite_items:Array = []
@export var feathers_earned_multiplier:float = 1.0
@export var materials_earned_multiplier:float = 1.0
@export var energy:int = 100
@export var feathers_gathered_multiplier:float = 1.0
@export var max_feather_capacity:int = 100
