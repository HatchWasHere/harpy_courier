extends Control
class_name ShopScreen

signal closed_secondary_scene

@onready var shop_item_description_label: Label = %ShopItemDescriptionLabel
@onready var confirm_item_purchase_window: Control = %ConfirmItemPurchaseWindow
@onready var shop_items_grid_container: GridContainer = %ShopItemsGridContainer
@onready var buy_button: Button = %BuyButton
@onready var back_button: Button = %BackButton
@onready var confirm_buy_button: Button = %ConfirmBuyButton
@onready var cancel_buy_button: Button = %CancelBuyButton
@onready var feathers_owned_label: Label = %FeathersOwnedLabel



var shop_inventory:Array[Item] = []
var picked_item

func _ready() -> void:
	buy_button.pressed.connect(pressed_buy_button)
	confirm_buy_button.pressed.connect(pressed_confirm_purchase)
	cancel_buy_button.pressed.connect(on_pressed_cancel_buy)
	back_button.pressed.connect(on_pressed_back_button)
	GameManager.feathers_changed.connect(update_screen)
	set_shop_inventory()
	call_shop_buttons()
	show_feather_count()

func update_screen():
	show_feather_count()

func show_feather_count():
	var count:int = GameManager.feathers
	feathers_owned_label.text = "Feathers: %d" % [count]

func set_shop_inventory():

	if GameManager.shop_manager == null: return
	
	var s_inv = GameManager.shop_manager.inventory
	if s_inv == null or s_inv.is_empty(): return
	
	shop_inventory = s_inv

func call_shop_buttons() -> void:
	
	if shop_inventory == null or shop_inventory.is_empty(): return
	
	for i in shop_inventory:
		var b = Button.new()
		b.custom_minimum_size = Vector2(150,150)
		shop_items_grid_container.add_child(b)
		b.pressed.connect(on_pressed_item_button.bind(i))
		

func on_pressed_item_button(item:Item):
	set_item_description_field(item.item_description)
	picked_item = item

func on_pressed_back_button():
	closed_secondary_scene.emit()
	await get_tree().process_frame
	queue_free()

func pressed_item_button(item):
	picked_item = item
	if item == null: return
	
	if not "description" in item:
		push_error("ERROR. Item resource missing 'description' var.")
		return
	
	set_item_description_field(item.description)

func pressed_buy_button():
	
	var s = GameManager.shop_manager
	
	if picked_item == null: return
	if s.can_buy_item(picked_item) == false: return
	
	show_confirm_purchase_window()

func set_item_description_field(field_text:String):
	
	if field_text == null: return
	
	shop_item_description_label.text = field_text

func on_pressed_confirm_buy():
	GameManager.shop_manager.buy_item(picked_item)
	picked_item = null
	hide_confirm_purchase_window()

func load_button(button:Button,item:Resource):
	
	if button == null: return
	
	button.pressed.connect(pressed_item_button.bind(item))

func show_confirm_purchase_window():
	
	if picked_item == null: return
	
	var c_a:bool = GameManager.can_afford_item(picked_item)
	if c_a == false: return
	
	confirm_item_purchase_window.show()

func pressed_confirm_purchase():
	
	if not picked_item: return
	
	GameManager.shop_manager.buy_item(picked_item)
	GameManager.mark_as_dirty()
	GameManager.save_game()
	hide_confirm_purchase_window()

func hide_confirm_purchase_window():
	confirm_item_purchase_window.hide()

func on_pressed_cancel_buy():
	hide_confirm_purchase_window()
